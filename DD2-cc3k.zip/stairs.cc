#include "stairs.h"

Stairs::Stairs (const int r, const int c, const int ch):Cell{r, c, "stairs", ch} {}
