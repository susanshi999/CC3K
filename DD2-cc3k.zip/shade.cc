#include "shade.h"

Shade::Shade(int r, int c,int ch):
  Player{r,c,"Shade",ch,125,25,25}{}

