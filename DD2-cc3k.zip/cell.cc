#include "cell.h"

Cell::Cell(const int r, const int c, const std::string & t, const int ch):
    Object{r, c, t, ch}{}
