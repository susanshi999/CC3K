#include "chamber.h"
using namespace std;

Chamber::Chamber(){

}

Chamber::~Chamber(){
	for (auto & r: cells){
		r.second.clear();
	}
	cells.clear();

	for (auto & r: items){
		r.second.clear();
	}
	items.clear();

	/*
  for (auto & r: enemies){
		r.clear();
	}
*/
	enemies.clear();
}


