#ifndef _TROLL_
#define _TROLL_
#include <iostream>
#include "player.h"

class Troll:public Player{


public:
  Troll(int row, int col,int chamber);
};

#endif
