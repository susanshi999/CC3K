#ifndef _SHADE_
#define _SHADE_
#include <iostream>
#include "player.h"

class Shade:public Player{


public:
  Shade(int row, int col,int chamber);
};

#endif
