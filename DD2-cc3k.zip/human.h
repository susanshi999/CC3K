#ifndef _HUMAN_
#define _HUMAN_
#include <iostream>
#include "enemy.h"

class Human:public Enemy{

public:
  Human(int row, int col,int chamber);

};

#endif
