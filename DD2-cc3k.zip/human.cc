#include "human.h"

Human::Human(int r, int c,int ch):
  Enemy{r,c,"Human",ch,140,20,20,'H'}{}
  //c{'H'}
