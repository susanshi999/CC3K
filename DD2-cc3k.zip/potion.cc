#include "potion.h"

Potion::Potion(const int row, const int col, const std::string type, const int chamber) :
    Item{row, col, type, chamber} {}

Potion::~Potion() {};

