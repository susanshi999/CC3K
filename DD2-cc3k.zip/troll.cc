#include "troll.h"

Troll::Troll(int r, int c,int ch):
  Player{r,c,"Troll",ch,120,25,15}{}
