#ifndef _STAIR_H
#define _STAIR_H
#include "cell.h"

class Stairs : public Cell{
public:
        Stairs(const int r, const int c, const int ch);
};

#endif
