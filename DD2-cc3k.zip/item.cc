#include "item.h"

Item::Item(const int row, const int col, const std::string type, const int chamber) :Object{row, col, type, chamber} {}
